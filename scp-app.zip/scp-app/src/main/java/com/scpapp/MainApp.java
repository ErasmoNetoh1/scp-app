package com.scpapp;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * MainApp — Interface gráfica com JavaFX (etapa 5).
 *
 * Para rodar a GUI:
 *   mvn javafx:run
 *
 * Conceitos JavaFX usados aqui:
 *   - Stage   = a janela do programa
 *   - Scene   = o "conteúdo" dentro da janela
 *   - Layout  = como os componentes são organizados (VBox = vertical, HBox = horizontal, GridPane = grade)
 *   - Control = botão, campo de texto, label, etc.
 *
 * "extends Application" significa que MainApp herda tudo da classe Application do JavaFX.
 * Herança é um conceito de OOP: a classe filha recebe os comportamentos da classe pai.
 */
public class MainApp extends Application {

    // -------------------------------------------------------------------------
    // CAMPOS DA CLASSE (componentes da interface e estado)
    // -------------------------------------------------------------------------

    // Campos de texto para as credenciais de conexão
    private TextField campHost;
    private TextField campUsuario;
    private PasswordField campSenha;  // PasswordField esconde o texto digitado

    // Labels de status
    private Label labelStatus;
    private Label labelConexao;

    // O gerenciador SSH (null se não conectado)
    private SSHManager ssh;

    // ExecutorService: roda tarefas em background sem travar a interface
    // Operações de rede são lentas — se rodassem na thread da UI, a janela "congelaria"
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    // -------------------------------------------------------------------------
    // PONTO DE ENTRADA
    // -------------------------------------------------------------------------

    /**
     * O main() de uma aplicação JavaFX apenas chama launch(),
     * que por sua vez chama start() abaixo.
     */
    public static void main(String[] args) {
        launch(args);
    }

    // -------------------------------------------------------------------------
    // start(): onde a janela é construída
    // -------------------------------------------------------------------------

    /**
     * start() é chamado automaticamente pelo JavaFX quando o app inicia.
     * Aqui construímos toda a interface.
     *
     * @param stage  A janela principal (JavaFX a cria e passa pra você)
     */
    @Override
    public void start(Stage stage) {

        // ---------------------------------------------------------------
        // TÍTULO E CONFIGURAÇÃO DA JANELA
        // ---------------------------------------------------------------
        stage.setTitle("SCP App");
        stage.setWidth(500);
        stage.setHeight(600);
        stage.setResizable(false);

        // ---------------------------------------------------------------
        // LAYOUT PRINCIPAL: VBox = organiza componentes verticalmente
        // Insets = espaçamento interno (top, right, bottom, left)
        // ---------------------------------------------------------------
        VBox root = new VBox(16);
        root.setPadding(new Insets(24));
        root.setStyle("-fx-background-color: #f8f9fa;");

        // ---------------------------------------------------------------
        // SEÇÃO 1: Título
        // ---------------------------------------------------------------
        Label titulo = new Label("SCP File Transfer");
        titulo.setFont(Font.font("System", FontWeight.BOLD, 20));
        titulo.setTextFill(Color.web("#1a1a2e"));

        // ---------------------------------------------------------------
        // SEÇÃO 2: Formulário de conexão (usando GridPane = grade)
        // GridPane organiza componentes em linhas e colunas
        // ---------------------------------------------------------------
        GridPane gridConexao = new GridPane();
        gridConexao.setHgap(10);  // espaço horizontal entre colunas
        gridConexao.setVgap(8);   // espaço vertical entre linhas
        gridConexao.setPadding(new Insets(16));
        gridConexao.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: #dee2e6;" +
            "-fx-border-radius: 8;" +
            "-fx-background-radius: 8;"
        );

        // Label de seção
        Label lblConexao = criarLabelSecao("Conexão SSH");
        gridConexao.add(lblConexao, 0, 0, 2, 1); // col=0, row=0, colSpan=2, rowSpan=1

        // Host
        gridConexao.add(new Label("Host:"), 0, 1);
        campHost = new TextField("localhost");
        campHost.setPromptText("IP ou hostname");
        campHost.setPrefWidth(280);
        gridConexao.add(campHost, 1, 1);

        // Usuário
        gridConexao.add(new Label("Usuário:"), 0, 2);
        campUsuario = new TextField();
        campUsuario.setPromptText("seu_usuario");
        gridConexao.add(campUsuario, 1, 2);

        // Senha
        gridConexao.add(new Label("Senha:"), 0, 3);
        campSenha = new PasswordField();
        campSenha.setPromptText("••••••••");
        gridConexao.add(campSenha, 1, 3);

        // Label de status da conexão
        labelConexao = new Label("● Desconectado");
        labelConexao.setTextFill(Color.web("#dc3545"));
        gridConexao.add(labelConexao, 0, 4, 2, 1);

        // Botão Conectar
        Button btnConectar = criarBotao("Conectar", "#0d6efd");
        btnConectar.setMaxWidth(Double.MAX_VALUE); // ocupa toda a largura disponível
        btnConectar.setOnAction(e -> acaoConectar()); // define o que acontece ao clicar
        gridConexao.add(btnConectar, 0, 5, 2, 1);

        // ---------------------------------------------------------------
        // SEÇÃO 3: Upload
        // ---------------------------------------------------------------
        VBox boxUpload = criarCardSecao("Upload (local → servidor)");

        TextField campArquivoLocal = new TextField();
        campArquivoLocal.setPromptText("Caminho do arquivo local");

        Button btnEscolherArquivo = new Button("Escolher arquivo...");
        btnEscolherArquivo.setOnAction(e -> {
            // FileChooser abre a janela de seleção de arquivo do sistema operacional
            FileChooser fc = new FileChooser();
            fc.setTitle("Selecionar arquivo para upload");
            File arquivo = fc.showOpenDialog(stage);
            if (arquivo != null) {
                campArquivoLocal.setText(arquivo.getAbsolutePath());
            }
        });

        TextField campDestinoRemoto = new TextField();
        campDestinoRemoto.setPromptText("Destino no servidor: /home/user/arquivo.txt");

        Button btnUpload = criarBotao("Fazer Upload", "#198754");
        btnUpload.setMaxWidth(Double.MAX_VALUE);
        btnUpload.setOnAction(e -> acaoUpload(campArquivoLocal.getText(), campDestinoRemoto.getText()));

        // HBox = organiza componentes horizontalmente
        HBox linhaArquivo = new HBox(8, campArquivoLocal, btnEscolherArquivo);
        HBox.setHgrow(campArquivoLocal, Priority.ALWAYS); // campArquivoLocal se expande

        boxUpload.getChildren().addAll(linhaArquivo, campDestinoRemoto, btnUpload);

        // ---------------------------------------------------------------
        // SEÇÃO 4: Download
        // ---------------------------------------------------------------
        VBox boxDownload = criarCardSecao("Download (servidor → local)");

        TextField campOrigemRemota = new TextField();
        campOrigemRemota.setPromptText("Arquivo no servidor: /var/log/app.log");

        TextField campDestinoLocal = new TextField();
        campDestinoLocal.setPromptText("Destino local: C:/Downloads/app.log");

        Button btnDownload = criarBotao("Fazer Download", "#6f42c1");
        btnDownload.setMaxWidth(Double.MAX_VALUE);
        btnDownload.setOnAction(e -> acaoDownload(campOrigemRemota.getText(), campDestinoLocal.getText()));

        boxDownload.getChildren().addAll(campOrigemRemota, campDestinoLocal, btnDownload);

        // ---------------------------------------------------------------
        // SEÇÃO 5: Status / Log de operações
        // ---------------------------------------------------------------
        labelStatus = new Label("Pronto.");
        labelStatus.setWrapText(true); // quebra linha se o texto for longo
        labelStatus.setStyle(
            "-fx-background-color: #212529;" +
            "-fx-text-fill: #adb5bd;" +
            "-fx-padding: 10;" +
            "-fx-font-family: monospace;" +
            "-fx-background-radius: 6;"
        );
        labelStatus.setMaxWidth(Double.MAX_VALUE);
        labelStatus.setMinHeight(60);

        // ---------------------------------------------------------------
        // MONTAGEM FINAL: adiciona todas as seções ao layout principal
        // ---------------------------------------------------------------
        root.getChildren().addAll(titulo, gridConexao, boxUpload, boxDownload, labelStatus);

        // Cria a Scene (conteúdo) e coloca na Stage (janela)
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show(); // Exibe a janela
    }

    // -------------------------------------------------------------------------
    // AÇÕES DOS BOTÕES
    // -------------------------------------------------------------------------

    /**
     * Conecta ao servidor SSH em background (sem travar a interface).
     */
    private void acaoConectar() {
        String host = campHost.getText().trim();
        String usuario = campUsuario.getText().trim();
        String senha = campSenha.getText();

        if (host.isEmpty() || usuario.isEmpty()) {
            atualizarStatus("✗ Preencha o host e o usuário.");
            return;
        }

        atualizarStatus("Conectando...");

        // Roda a conexão em outra thread para não travar a janela
        executor.submit(() -> {
            try {
                SSHManager novoSsh = new SSHManager(host, usuario, senha);
                novoSsh.conectar();
                ssh = novoSsh;

                // Platform.runLater: atualiza a interface a partir de outra thread
                // JavaFX só permite modificar componentes na thread principal (UI thread)
                Platform.runLater(() -> {
                    labelConexao.setText("● Conectado em " + host);
                    labelConexao.setTextFill(Color.web("#198754"));
                    atualizarStatus("✓ Conectado em " + host + " como " + usuario);
                });

            } catch (Exception e) {
                Platform.runLater(() -> {
                    ssh = null;
                    atualizarStatus("✗ Erro ao conectar: " + e.getMessage());
                });
            }
        });
    }

    /**
     * Faz upload de um arquivo em background.
     */
    private void acaoUpload(String caminhoLocal, String caminhoRemoto) {
        if (!verificarConectado()) return;
        if (caminhoLocal.isEmpty() || caminhoRemoto.isEmpty()) {
            atualizarStatus("✗ Preencha os campos de upload.");
            return;
        }

        atualizarStatus("Fazendo upload de " + caminhoLocal + "...");

        executor.submit(() -> {
            try {
                ssh.upload(caminhoLocal, caminhoRemoto);
                Platform.runLater(() ->
                    atualizarStatus("✓ Upload concluído: " + caminhoLocal + " → " + caminhoRemoto)
                );
            } catch (Exception e) {
                Platform.runLater(() ->
                    atualizarStatus("✗ Erro no upload: " + e.getMessage())
                );
            }
        });
    }

    /**
     * Faz download de um arquivo em background.
     */
    private void acaoDownload(String caminhoRemoto, String caminhoLocal) {
        if (!verificarConectado()) return;
        if (caminhoRemoto.isEmpty() || caminhoLocal.isEmpty()) {
            atualizarStatus("✗ Preencha os campos de download.");
            return;
        }

        atualizarStatus("Fazendo download de " + caminhoRemoto + "...");

        executor.submit(() -> {
            try {
                ssh.download(caminhoRemoto, caminhoLocal);
                Platform.runLater(() ->
                    atualizarStatus("✓ Download concluído: " + caminhoRemoto + " → " + caminhoLocal)
                );
            } catch (Exception e) {
                Platform.runLater(() ->
                    atualizarStatus("✗ Erro no download: " + e.getMessage())
                );
            }
        });
    }

    // -------------------------------------------------------------------------
    // MÉTODOS AUXILIARES
    // -------------------------------------------------------------------------

    private boolean verificarConectado() {
        if (ssh == null) {
            atualizarStatus("✗ Conecte-se primeiro.");
            return false;
        }
        return true;
    }

    private void atualizarStatus(String mensagem) {
        labelStatus.setText(mensagem);
    }

    private Label criarLabelSecao(String texto) {
        Label label = new Label(texto);
        label.setFont(Font.font("System", FontWeight.BOLD, 13));
        label.setTextFill(Color.web("#495057"));
        return label;
    }

    private Button criarBotao(String texto, String corHex) {
        Button btn = new Button(texto);
        btn.setStyle(
            "-fx-background-color: " + corHex + ";" +
            "-fx-text-fill: white;" +
            "-fx-padding: 8 16;" +
            "-fx-background-radius: 6;" +
            "-fx-cursor: hand;"
        );
        return btn;
    }

    private VBox criarCardSecao(String titulo) {
        VBox card = new VBox(8);
        card.setPadding(new Insets(14));
        card.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: #dee2e6;" +
            "-fx-border-radius: 8;" +
            "-fx-background-radius: 8;"
        );

        Label lbl = criarLabelSecao(titulo);
        card.getChildren().add(lbl);

        return card;
    }

    /**
     * stop() é chamado pelo JavaFX quando o usuário fecha a janela.
     * É o lugar certo para liberar recursos (fechar conexão, parar threads).
     */
    @Override
    public void stop() throws Exception {
        executor.shutdown(); // Para de aceitar novas tarefas em background
        if (ssh != null) ssh.desconectar();
    }
}
